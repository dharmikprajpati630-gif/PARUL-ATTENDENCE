/* Parul University Attendance Portal (static demo)
   - Works offline (no server) using localStorage.
   - Perfect for quick presentation.
*/

const PortalData = (() => {
  const KEY = "PU_ATT_PORTAL_V1";

  const nowISO = () => new Date().toISOString();
  const prettyTime = (iso) => {
    try { return new Date(iso).toLocaleString(); } catch { return iso; }
  };

  const seed = () => ({
    lecture: { active:false, subject:"", startISO:"", endISO:"", windowText:"" },
    students: [
      { enrollment:"2403466160146", name:"Sumit Rohit", password:"1234" },
      { enrollment:"2403466160147", name:"Jeevanantham G", password:"1234" },
      { enrollment:"2403466160148", name:"Risabh Patel", password:"1234" }
    ],
    attendance: []
  });

  const load = () => {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      const s = seed();
      localStorage.setItem(KEY, JSON.stringify(s));
      return s;
    }
    try { return JSON.parse(raw); }
    catch {
      const s = seed();
      localStorage.setItem(KEY, JSON.stringify(s));
      return s;
    }
  };

  const save = (state) => localStorage.setItem(KEY, JSON.stringify(state));

  const resetDemo = () => {
    localStorage.removeItem(KEY);
    localStorage.removeItem("PU_SESSION_STUDENT");
    localStorage.removeItem("PU_SESSION_TEACHER");
    const s = seed();
    localStorage.setItem(KEY, JSON.stringify(s));
    PortalUI.toast("Demo data reset ✅");
  };

  return { load, save, nowISO, prettyTime, resetDemo };
})();

const PortalAuth = (() => {
  const studentKey = "PU_SESSION_STUDENT";
  const teacherKey = "PU_SESSION_TEACHER";

  const studentLogin = () => {
    const enr = document.getElementById("sEnroll")?.value?.trim();
    const pass = document.getElementById("sPass")?.value?.trim();
    const msg = document.getElementById("sMsg");
    const state = PortalData.load();

    const s = state.students.find(x => x.enrollment === enr && x.password === pass);
    if (!s) {
      if (msg) { msg.style.color="#b91c1c"; msg.textContent="Invalid login. Demo: 2403466160146 / 1234"; }
      return;
    }
    localStorage.setItem(studentKey, JSON.stringify({ enrollment:s.enrollment, name:s.name }));
    window.location.href = "student-dashboard.html";
  };

  const teacherLogin = () => {
    const u = document.getElementById("tUser")?.value?.trim();
    const p = document.getElementById("tPass")?.value?.trim();
    const msg = document.getElementById("tMsg");

    if (u !== "teacher" || p !== "teacher123") {
      if (msg) { msg.style.color="#b91c1c"; msg.textContent="Invalid login. Demo: teacher / teacher123"; }
      return;
    }
    localStorage.setItem(teacherKey, JSON.stringify({ username:"teacher", name:"Faculty" }));
    window.location.href = "teacher-dashboard.html";
  };

  const getStudent = () => {
    try { return JSON.parse(localStorage.getItem(studentKey) || "null"); } catch { return null; }
  };

  const getTeacher = () => {
    try { return JSON.parse(localStorage.getItem(teacherKey) || "null"); } catch { return null; }
  };

  const logout = (role) => {
    if (role === "student") localStorage.removeItem(studentKey);
    if (role === "teacher") localStorage.removeItem(teacherKey);
    window.location.href = "index.html";
  };

  return { studentLogin, teacherLogin, getStudent, getTeacher, logout };
})();

const PortalGuard = (() => {
  const requireStudent = () => { if (!PortalAuth.getStudent()) window.location.href="student-login.html"; };
  const requireTeacher = () => { if (!PortalAuth.getTeacher()) window.location.href="teacher-login.html"; };
  return { requireStudent, requireTeacher };
})();

const PortalLecture = (() => {
  const start = () => {
    const subject = document.getElementById("subject")?.value?.trim() || "Computer Networks";
    const durationMin = parseInt(document.getElementById("duration")?.value || "60", 10);
    const state = PortalData.load();

    const startISO = PortalData.nowISO();
    const endISO = new Date(Date.now() + durationMin*60*1000).toISOString();

    state.lecture.active = true;
    state.lecture.subject = subject;
    state.lecture.startISO = startISO;
    state.lecture.endISO = endISO;
    state.lecture.windowText = `${new Date(startISO).toLocaleTimeString()} - ${new Date(endISO).toLocaleTimeString()}`;

    PortalData.save(state);
    const msg = document.getElementById("tCtrlMsg");
    if (msg) { msg.style.color="#166534"; msg.textContent = `Lecture started: ${subject}`; }
    PortalUI.toast("Lecture started ✅");
    PortalUI.renderTeacherDashboard();
  };

  const end = () => {
    const state = PortalData.load();
    if (!state.lecture.active) {
      const msg = document.getElementById("tCtrlMsg");
      if (msg) { msg.style.color="#b91c1c"; msg.textContent="No active lecture."; }
      PortalUI.toast("No active lecture.");
      return;
    }
    state.lecture.active = false;
    PortalData.save(state);
    const msg = document.getElementById("tCtrlMsg");
    if (msg) { msg.style.color="#166534"; msg.textContent="Lecture ended. Attendance locked."; }
    PortalUI.toast("Lecture ended ✅");
    PortalUI.renderTeacherDashboard();
  };

  return { start, end };
})();

const PortalAttendance = (() => {
  const markForCurrentStudent = () => {
    const s = PortalAuth.getStudent();
    const msg = document.getElementById("markMsg");
    const btn = document.getElementById("markBtn");
    const state = PortalData.load();

    if (!state.lecture.active) {
      if (msg) { msg.style.color="#b91c1c"; msg.textContent="Lecture NOT active. Ask teacher to start."; }
      return;
    }

    const already = state.attendance.find(a => a.enrollment===s.enrollment && a.lectureStartISO===state.lecture.startISO);
    if (already) {
      if (msg) { msg.style.color="#b91c1c"; msg.textContent="Already marked for this lecture."; }
      return;
    }

    state.attendance.unshift({
      enrollment: s.enrollment,
      name: s.name,
      markedISO: PortalData.nowISO(),
      subject: state.lecture.subject,
      lectureStartISO: state.lecture.startISO
    });
    PortalData.save(state);

    if (msg) { msg.style.color="#166534"; msg.textContent="✅ Attendance Marked Successfully"; }
    if (btn) { btn.disabled=true; btn.textContent="Marked"; }
    PortalUI.toast("Attendance saved ✅");
    PortalUI.renderStudentAttendancePage();
  };

  return { markForCurrentStudent };
})();

const PortalReport = (() => {
  const refresh = () => {
    const state = PortalData.load();
    const meta = document.getElementById("repMeta");
    const body = document.getElementById("repBody");
    if (!body) return;

    const st = state.lecture.active ? "ACTIVE" : "ENDED";
    const subj = state.lecture.subject || "—";
    const win = state.lecture.windowText || "—";
    if (meta) meta.textContent = `Status: ${st} | Subject: ${subj} | Window: ${win}`;

    body.innerHTML = "";
    const rows = state.attendance.filter(a => state.lecture.startISO ? (a.lectureStartISO===state.lecture.startISO) : true);
    if (rows.length===0) {
      body.innerHTML = `<tr><td colspan="5" class="muted">No attendance yet.</td></tr>`;
      return;
    }
    rows.forEach((r,i) => {
      body.insertAdjacentHTML("beforeend",
        `<tr>
          <td>${i+1}</td>
          <td>${r.enrollment}</td>
          <td>${r.name}</td>
          <td>${PortalData.prettyTime(r.markedISO)}</td>
          <td><span class="badge">Present</span></td>
        </tr>`
      );
    });
  };

  const downloadCSV = () => {
    const state = PortalData.load();
    const rows = state.attendance;
    const header = ["Enrollment","Name","Subject","MarkedAt"];
    const csv = [header.join(",")].concat(
      rows.map(r => [r.enrollment,r.name,r.subject,r.markedISO].map(x => `"${String(x).replaceAll('"','""')}"`).join(","))
    ).join("\n");

    const blob = new Blob([csv], {type:"text/csv"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href=url; a.download="Parul_Attendance_Report.csv";
    a.click(); URL.revokeObjectURL(url);
    PortalUI.toast("CSV downloaded ✅");
  };

  return { refresh, downloadCSV };
})();

const PortalUI = (() => {
  let toastTimer = null;

  const toast = (text) => {
    const t = document.getElementById("toast");
    if (!t) return;
    t.textContent = text;
    t.style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=> t.style.display="none", 2200);
  };

  const renderHomeKPIs = () => {
    const state = PortalData.load();
    const st = state.lecture.active ? "ACTIVE" : "NOT ACTIVE";
    const subj = state.lecture.subject || "—";
    const date = new Date().toLocaleDateString();
    const marked = state.attendance.filter(a => a.lectureStartISO===state.lecture.startISO).length;

    const s = document.getElementById("kpiStatus");
    const su = document.getElementById("kpiSubject");
    const d = document.getElementById("kpiDate");
    const m = document.getElementById("kpiMarked");
    const b = document.getElementById("badgeLecture");
    if (s) s.textContent = st;
    if (su) su.textContent = subj;
    if (d) d.textContent = date;
    if (m) m.textContent = String(marked);
    if (b) b.textContent = `Lecture: ${st} | ${subj}`;
  };

  const renderPreviewTable = () => {
    const state = PortalData.load();
    const body = document.getElementById("previewBody");
    if (!body) return;
    const rows = state.attendance.slice(0,4);
    if (rows.length===0){
      body.innerHTML = `<tr><td colspan="3" class="muted">No attendance yet.</td></tr>`;
      return;
    }
    body.innerHTML = "";
    rows.forEach(r => {
      body.insertAdjacentHTML("beforeend",
        `<tr><td>${r.enrollment}</td><td>${r.name}</td><td>${PortalData.prettyTime(r.markedISO)}</td></tr>`
      );
    });
  };

  const renderStudentDashboard = () => {
    const state = PortalData.load();
    const s = PortalAuth.getStudent();
    const pill = document.getElementById("pillStatus");
    const subj = document.getElementById("curSubject");
    const mark = document.getElementById("yourMark");

    if (pill) pill.textContent = `Status: ${state.lecture.active ? "ACTIVE" : "NOT ACTIVE"}`;
    if (subj) subj.textContent = state.lecture.subject || "—";

    const already = state.attendance.find(a => a.enrollment===s.enrollment && a.lectureStartISO===state.lecture.startISO);
    if (mark) mark.textContent = already ? "Marked" : "Not Marked";
  };

  const renderStudentAttendancePage = () => {
    const state = PortalData.load();
    const pill = document.getElementById("pillStatus");
    const subj = document.getElementById("subj");
    const win = document.getElementById("window");
    const btn = document.getElementById("markBtn");
    const msg = document.getElementById("markMsg");
    const s = PortalAuth.getStudent();

    if (pill) pill.textContent = `Status: ${state.lecture.active ? "ACTIVE" : "NOT ACTIVE"}`;
    if (subj) subj.textContent = `Subject: ${state.lecture.subject || "—"}`;
    if (win) win.textContent = `Window: ${state.lecture.windowText || "—"}`;

    const already = state.attendance.find(a => a.enrollment===s.enrollment && a.lectureStartISO===state.lecture.startISO);
    if (btn){
      btn.disabled = !state.lecture.active || !!already;
      btn.textContent = already ? "Marked" : "✔ Mark Attendance";
    }
    if (msg && already){
      msg.style.color="#166534";
      msg.textContent="✅ Attendance Marked Successfully";
    }
  };

  const renderTeacherDashboard = () => {
    const state = PortalData.load();
    const pill = document.getElementById("pillStatus");
    const subj = document.getElementById("tSubject");
    const count = document.getElementById("tCount");
    const win = document.getElementById("tWindow");

    if (pill) pill.textContent = `Status: ${state.lecture.active ? "ACTIVE" : "NOT ACTIVE"}`;
    if (subj) subj.textContent = state.lecture.subject || "—";
    if (win) win.textContent = state.lecture.windowText || "—";
    if (count) count.textContent = String(state.attendance.filter(a => a.lectureStartISO===state.lecture.startISO).length);
  };

  const renderLectureBadge = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const state = PortalData.load();
    el.textContent = `Lecture: ${state.lecture.active ? "ACTIVE" : "NOT ACTIVE"} | ${state.lecture.subject || "—"}`;
  };

  return {
    toast,
    renderHomeKPIs,
    renderPreviewTable,
    renderStudentDashboard,
    renderStudentAttendancePage,
    renderTeacherDashboard,
    renderLectureBadge
  };
})();

// Expose to window for inline onclick usage
window.PortalData = PortalData;
window.PortalAuth = PortalAuth;
window.PortalGuard = PortalGuard;
window.PortalLecture = PortalLecture;
window.PortalAttendance = PortalAttendance;
window.PortalReport = PortalReport;
window.PortalUI = PortalUI;
