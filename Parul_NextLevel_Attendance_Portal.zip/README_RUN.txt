PARUL UNIVERSITY - SMART ATTENDANCE PORTAL (DEMO)

FAST RUN:
1) Extract ZIP
2) Open index.html in Chrome (double click)

Demo Accounts:
- Student: 2403466160146 / 1234
- Teacher: teacher / teacher123

Presentation Flow:
Teacher Login -> Start Lecture -> Student Login -> Mark Attendance -> Report -> Download CSV
